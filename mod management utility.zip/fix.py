# python fix.py
# python fix.py
import os
import subprocess
import time
import signal

# 运行修复程序
def fixexe(mainpath, mainexe):

    mainexe = os.path.join(mainpath, mainexe)
    fix = subprocess.Popen(mainexe, stdin=subprocess.PIPE, text=True)
    
    # 等待程序结束
    time.sleep(10)
    fix.communicate(input='\n')

# 运行修复程序
def fixexe2(mainpath, mainexe):

    mainexe = os.path.join(mainpath, mainexe)
    # 使用 subprocess.Popen 来运行可执行文件
    process = subprocess.Popen(mainexe)
    
    # 等待10秒
    time.sleep(10)
    
    # 尝试杀死进程
    try:
        if os.name == 'nt':  # 如果是Windows系统
            os.kill(process.pid, signal.SIGTERM)  # 使用SIGTERM信号
        else:  # 如果是Unix/Linux系统
            os.kill(process.pid, signal.SIGKILL)  # 使用SIGKILL信号
        print(f"Process {process.pid} has been terminated.")
    except Exception as e:
        print(f"Error terminating process: {e}")

if __name__ == '__main__':
    # mod文件夹路径
    mainpath = './'
    # 修复程序路径
    mainexe = './genshin_update_mods_47_ecf92.exe'
    # 调用修复程序运行函数
    fixexe(mainpath, mainexe)
    # 调用修复程序运行函数
    # fixexe2(mainpath, mainexe)
    # 程序运行结束
    print('done')