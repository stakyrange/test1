# python rarundo.py
# 解压文件
import os
import zipfile
import rarfile
import py7zr
import config
 
def mkdir(path):
    isExists = os.path.exists(path)
    if not isExists:
        os.makedirs(path)
        print(path + '创建成功')
    else:
        print(path + '目录已存在')
 
def unzipFile(folder_path):
    wrong_log = os.path.join(folder_path, 'unzip_log.txt')
    for root, dirs, files in os.walk(folder_path):
        contents = os.listdir(root)
        folders = [folder for folder in contents if os.path.isdir(os.path.join(root, folder))]  # 该目录下文件夹名称列表
        for file in files:
            if file.endswith('7z'):
                zipFile_name = file.split('.')[0:-1]
                zipFile_name = '.'.join(zipFile_name)
                if zipFile_name in folders:
                    continue
                # 没有重名文件则进行解压
                else:
                    # 创建解压文件夹路径
                    unzip_zipFile_path = os.path.join(root, zipFile_name)
                    mkdir(unzip_zipFile_path)
                    zipFile_path = os.path.join(root, file)
                    print(zipFile_path)
                    try:
                        with py7zr.SevenZipFile(zipFile_path, mode='r') as z:
                            z.extractall(path=unzip_zipFile_path)
                    except:
                        with open(wrong_log, 'a') as f:
                            f.write(f'\n {zipFile_path}')
 
            elif file.endswith('rar'):  # file 是待解压文件
                # 有重名文件说明被解压过，跳过
                rarFile_name = file.split('.')[0:-1]
                rarFile_name = '.'.join(rarFile_name)
                if rarFile_name in folders:
                    continue
                # 没有重名文件则进行解压
                else:
                    # 创建解压文件夹路径
                    unzip_rarFile_path = os.path.join(root, rarFile_name)
                    mkdir(unzip_rarFile_path)
                    rarFile_path = os.path.join(root, file)
                    print(rarFile_path)
                    try:
                        with rarfile.RarFile(rarFile_path) as rar_ref:
                            rar_ref.extractall(unzip_rarFile_path)
                    except:
                        pass
                        with open(wrong_log, 'a') as f:
                            f.write(f'\n {rarFile_path}')
 
            elif file.endswith('zip'):  # file 是待解压文件
                # 有重名文件说明被解压过，跳过
                rarFile_name = file.split('.')[0:-1]
                rarFile_name = '.'.join(rarFile_name)
                if rarFile_name in folders:
                    continue
                # 没有重名文件则进行解压
                else:
                    # 创建解压文件夹路径
                    unzip_rarFile_path = os.path.join(root, rarFile_name)
                    mkdir(unzip_rarFile_path)
                    rarFile_path = os.path.join(root, file)
                    print(rarFile_path)
                    try:
                        with zipfile.ZipFile(rarFile_path, 'r') as zip_ref:
                            zip_ref.extractall(unzip_rarFile_path)
                    except:
                        with open(wrong_log, 'a') as f:
                            f.write(f'\n {rarFile_path}')
            else:
                continue

def delete_zip_files(directory):
    # 获取目标目录下的所有文件
    files = os.listdir(directory)
    
    # 筛选出所有的压缩包文件
    zip_files = [f for f in files if f.endswith(('.zip', '.tar', '.rar'))]
    
    # 输出压缩包文件列表
    print(f"找到以下压缩包文件: {zip_files}")

    # 批量删除压缩包
    for zip_file in zip_files:
        file_path = os.path.join(directory, zip_file)
        os.remove(file_path)
        print(f"已删除: {zip_file}")

if __name__ == "__main__":
    # 文件路径
    path1 = config.path2
    # 遍历所有角色名
    FileList = os.listdir(path1)
    FileList2 = []
    # 把所有角色的文件夹内的所有文件路径写进FileList2变量
    for i in FileList:
        print(i)
        FileList2.append(path1+i)
    for i in FileList2:
        print(i)
        '解压文件'
        unzipFile(i)
 