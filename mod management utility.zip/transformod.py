# python transformod.py
# 替换模组
import shutil
import os
import csv
import config

# 复制文件夹
def copyfile(srcpath, dstpath):
    # 如果目标根目录不存在，则创建目标根目录。
    if not os.path.exists(dstpath):
        os.makedirs(dstpath)
    # 遍历源文件夹，得到根目录，子目录和文件名列表
    for root, dirs, files in os.walk(srcpath, topdown=True):
        # 将目录中根目录部分换成目标目录
        path = root.replace(srcpath, dstpath)
        # 在目标目录中,建立与源目录一样的目录体系
        for dir in dirs:
            if not os.path.exists(os.path.join(path, dir)):
                os.makedirs(os.path.join(path, dir))
        #获取文件名依次遍历
        for name in files:
            # 拷贝文件。
            shutil.copy(os.path.join(root, name), os.path.join(path, name))

# 删除文件夹
def delfolder(file):
    shutil.rmtree(file)    #递归删除文件夹，即：删除非空文件夹

# 删除mod文件夹
def delmodfolder(character, path):
    # 检查文件是否存在，如果不存在则创建并写入标题
    if not os.path.exists('./star rail hadmodname.csv'):
        with open('./star rail hadmodname.csv', 'w', encoding='UTF-8', newline='') as f:
            mod_dict = {'name': 'hadmodname'}
            csv_write = csv.writer(f)
            csv_write.writerow(mod_dict.keys())  # 写入标题行
    # with open('star rail hadmodname.csv', 'r', encoding='UTF-8', newline='') as f:
    #     csv_reader = csv.reader(f)
    #     for i in csv_reader:
    #         if i[0] == character:
    #             if i[1] != '':
    #                 path = r'D:\\game\\XXMI-Launcher-Portable-v1.3.2\\SRMI\\Mods\\' + character
    #                 delfolder(path)
    with open('star rail hadmodname.csv', 'r', encoding='UTF-8', newline='') as f:
        csv_reader = csv.reader(f)
        next(csv_reader)  # 跳过标题行
        for row in csv_reader:
            if len(row) > 1 and row[0] == character:
                if row[1]:  # 确保第二列存在且不为空
                    path = path + character
                    delfolder(path)
                    break  # 找到并处理了对应的角色，退出循环

# 对已有mod名进行保存
def recoder(character, hadmodname):
    file_path = './star rail hadmodname.csv'
    
    # 检查文件是否存在，如果不存在则创建并写入标题
    if not os.path.exists(file_path):
        with open(file_path, 'w', encoding='UTF-8', newline='') as f:
            mod_dict = {'name': 'hadmodname'}
            csv_write = csv.writer(f)
            csv_write.writerow(mod_dict.keys())  # 写入标题行

    # 读取文件内容并更新字典
    with open(file_path, 'r', encoding='UTF-8', newline='') as f:
        reader = csv.DictReader(f)
        mod_dict = {row['name']: row['hadmodname'] for row in reader}
    # 更新或添加新的键值对
    mod_dict[character] = hadmodname
    
    # 将更新后的字典写回文件
    with open(file_path, 'w', encoding='UTF-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['name', 'hadmodname'])
        writer.writeheader()  # 写入标题栏
        for name, hadmodname in mod_dict.items():
            writer.writerow({'name': name, 'hadmodname': hadmodname})

# 显示当前所有mod名
def display():
    with open('star rail.csv', 'r', encoding='UTF-8', newline='') as f:
        csv_reader = csv.reader(f)
        count = 1
        for i in csv_reader:
            print(f'{count-1}:'+str(i))
            count = count + 1

# 进行选择转移的mod文件
def select(character, number, path):
    csv_reader = csv.reader(open('star rail.csv'))
    count = 0
    for i in csv_reader:
        if count == character:
            modname = eval(i[1])[number-1]
            Fileroad = path+str(i[0])+'\\'+str(modname)
            if len(os.listdir(Fileroad)) < 3:
                Fileroad = path+str(i[0])+'\\'+str(modname)+'\\'+str(modname)
            character = i[0]
        count = count + 1
    return character, modname, Fileroad

if __name__ == '__main__':
    # 文件路径
    path1 = config.path3
    path2 = config.path2
    # 显示所有mod名
    display()
    print("please input character'number and mod'number(split with the comma)")
    # 键盘录入（以,隔开）
    a = input()
    # 分开键盘录入的数字
    character, number = int(a.split(',')[0]), int(a.split(',')[1])
    # 找到需要转移的mod文件相关信息
    character, modname, Fileroad = select(character, number, path2)
    # 目的地文件路径
    dstpath = path1+str(character)
    # 删除已存在的当前角色mod文件夹
    try:
        delmodfolder(character, path1)
    except:
        pass
    # 转移mod文件进mod加载器内
    copyfile(Fileroad, dstpath)
    # 对转移的mod名进行记录
    recoder(character, modname)
