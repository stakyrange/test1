# python deletefiles.py
# 删除文件
import os
import shutil
import config

def delete_zip_files(directory):
    # 获取目标目录下的所有文件
    files = os.listdir(directory)
    
    # 筛选出所有的压缩包文件
    zip_files = [f for f in files if f.endswith(('.zip', '.tar', '.rar', '.7z'))]
    
    # 输出压缩包文件列表
    print(f"find these zip files: {zip_files}")

    # 批量删除压缩包
    for zip_file in zip_files:
        file_path = os.path.join(directory, zip_file)
        os.remove(file_path)
        print(f"had deleted: {zip_file}")

def delete_folder(directory, name, path):
    # 获取目标目录下的所有文件
    a = os.listdir(directory)
    
    files = []
    for i in a:
        files.append(path+name+'\\'+i)

    folders = [f for f in files if os.path.isdir(f)]
    
    # 输出文件夹列表
    print(f"find these folder: {folders}")

    # 批量删除文件夹
    for folder in folders:
        file_path = os.path.join(directory, folder)
        shutil.rmtree(file_path)
        print(f"had deleted: {file_path}")

def delete_files(directory, name, path):
    # 获取目标目录下的所有文件
    a = os.listdir(directory)
    
    files = []
    for i in a:
        files.append(path+name+'\\'+i)

    files = [f for f in files if os.path.isfile(f)]
    
    # 输出文件列表
    print(f"find these files: {files}")

    # 批量删除文件
    for file in files:
        os.remove(file)
        print(f"had deleted: {file}")

if __name__ == "__main__":
    # 文件夹路径
    path1 = config.path2
    # 遍历所有角色
    FileList = os.listdir(path1)
    FileList2 = []
    # 把所有角色的路径存放进FileList2变量
    for i in FileList:
        FileList2.append(path1+i)

    # 键盘输入选择删除什么类型的文件
    select = input('please select whether folder or zip file or file or all in\n or zip file and file(1 or 2 or 3 or 4 or 5)')

    # 选择分支
    for i in FileList2:
        # 删除文件夹
        if select == '1':
            a = i.split("\\")
            chaname = a[-1]
            delete_folder(i, chaname, path1)
        # 删除压缩文件
        elif select == '2':
            delete_zip_files(i)
        # 删除文件
        elif select == '3':
            a = i.split("\\")
            chaname = a[-1]
            delete_files(i, chaname, path1)
        # 删除所有文件
        elif select == '4':
            a = i.split("\\")
            chaname = a[-1]
            delete_zip_files(i)
            delete_folder(i, chaname, path1)
            delete_files(i, chaname, path1)
        elif select == '5':
            a = i.split("\\")
            chaname = a[-1]
            delete_zip_files(i)
            delete_files(i, chaname, path1)
        # 防止输入错误
        else:
            pass