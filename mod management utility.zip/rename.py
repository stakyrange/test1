# python rename.py
# 如果解压出来是双层文件夹且名字不一样 那就用这个
import os
import shutil
import config

# 复制文件夹
def copyfile(srcpath, dstpath):
    # 如果目标根目录不存在，则创建目标根目录。
    if not os.path.exists(dstpath):
        os.makedirs(dstpath)
    # 遍历源文件夹，得到根目录，子目录和文件名列表
    for root, dirs, files in os.walk(srcpath, topdown=True):
        # 将目录中根目录部分换成目标目录
        path = root.replace(srcpath, dstpath)
        # 在目标目录中,建立与源目录一样的目录体系
        for dir in dirs:
            if not os.path.exists(os.path.join(path, dir)):
                os.makedirs(os.path.join(path, dir))
        #获取文件名依次遍历
        for name in files:
            # 拷贝文件。
            shutil.copy(os.path.join(root, name), os.path.join(path, name))

# 删除文件夹
def delete_file(directory):
    # 获取目标目录下的所有文件
    a = os.listdir(directory)
   
    # 批量删除压缩包
    for file in a:
        file_path = os.path.join(directory, file)
        try:
            shutil.rmtree(file_path)
            print(f"已删除: {file_path}")
        except:
            pass

# 文件路径
path1 = config.path2
path2 = config.path4

# 遍历所有角色名
FileList = os.listdir(path1)
FileList2 = []
# 将所有mod文件路径存放在FileList2变量里
for i in FileList:
    FileList2.append(path1+i)
FileList3 = []
namelist = []
# 遍历所有角色的mod文件夹
for i in FileList2:
    a = os.listdir(fr'{i}')
    for k in a:
        namelist.append(k)
        FileList3.append(f'{i}\\'+k+'\\')
# 遍历所有角色的mod路径并对双层文件夹如果双层文件夹不是相同名字进行改名以便之后代码的正确运行
for i in FileList3:
    try:
        a = os.listdir(fr'{i}')
    except:
        print(f'{i} not the mod folder')
    # 如果mod文件夹内的文件少于3个（该mod文件是双层文件夹），则检查里外层名称是否一致并对不一致的双层文件夹进行改名
    if len(a) < 3:
        for j in a:
            if j not in namelist:
                if os.path.isdir(fr'{i}'+j):
                    copyfile(fr'{i}'+j, path2+i.split('\\')[-3])
                    print(fr'{i}'+j, path2+i.split('\\')[-3])
                    delete_file(fr'{i}')
                    copyfile(path2+i.split('\\')[-3], fr'{i}')
                    print(f"have renamed the folder's name{i}")
                    delete_file(path2)

