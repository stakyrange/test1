# python writemodname.py
# 写入所有模组名
import os
import csv
import config

# 角色名列表（并没有用到）
charachater_list = ['himeko', 'welt', 'silver wolf', 'bronya', 'clara',\
                    'luocha', 'jingyuan', 'blade', 'fuxuan', 'yanqing', \
                    'bailu', 'jingliu', 'yunli', 'fugue', 'ruanmei', 'dr.ratio',\
                    'sparkle', 'firefly', 'march 7th', 'danheng', 'arlan', 'asta',\
                    'herta', 'serval', 'natasha', 'pela', 'sampo', 'hook', 'lynx',\
                    'luka', 'qingque', 'tingyun', 'sushang', 'yukong', 'guinaifen',\
                    'xueyi', 'hanya', 'moze', 'gallagher', 'misha', 'kafka',\
                    'seele', 'gepard', 'topaz&numby', 'danheng-plus', 'huohuo',\
                    'jiaoqiu', 'feixiao', 'lingsha', 'argenti', 'aventuring',\
                    'black swan', 'acheron', 'robin', 'sunday', 'jade', 'boothill',\
                    'rappa'
                    ]

# 文件路径
path1 = config.path2
# 遍历所有角色名
FileList = os.listdir(path1)
FileList2 = []
# 遍历所有角色的文件夹并保存所有mod路径进FileList2变量
for i in FileList:
    FileList2.append(path1+i)
top = ['name', 'type']
# 清空star rail.csv文件（以便写入不重复）
with open('star rail.csv','a+',encoding='utf-8') as f:
    f.truncate(0)
# 写入标题栏
with open('star rail.csv', 'a+', encoding='UTF-8', newline = '') as f:
    csv_write = csv.writer(f)
    csv_write.writerow(top)
for i in FileList2:
    FileList = os.listdir(fr'{i}')
    name = i.split('\\')[-1]
    data = {}
    data[name] = FileList
    # 写入所有角色的mod名字进star rail.csv文件
    with open('star rail.csv', 'a+', encoding='UTF-8', newline = '') as f:
        csv_write = csv.writer(f)
        for i in data.items():
            csv_write.writerow(i)

    

