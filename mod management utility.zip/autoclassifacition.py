# python autoclassification.py
import os
import shutil
import config

# 复制文件夹（单一文件）
def copyfile(srcpath, dstpath):
    shutil.copy(srcpath, dstpath)

# 删除文件夹（单一文件）
def deletefile(file):
    os.remove(file)

# 文件夹路径
path1 = config.path1
path2 = config.path2
# 遍历下载好的mod文件得到其名字
foldername = os.listdir(path1)

# 分类的各角色小名及英文名
charachater_dict = config.charachater_dict

# 创建字典以保存各角色的mod名字
charachater_dict2 = {}
# 创建一个变量存放当前保存的是哪个角色；如果下一个文件没有找到角色名或者小名则使用这个变量保存的角色名来写进字典
charachater = None

# 遍历所有mod文件名来保存各角色的mod名字
for i in foldername:
    for j, k in charachater_dict.items():
        # if i.find(j):
        if j in i:
            if j not in charachater_dict2:
                charachater_dict2[j] = [i]
            else:
                charachater_dict2[j].append(i)
            charachater = j
        for i2 in k:
            # if i.find(i2):
            if i2 in i:
                if j not in charachater_dict2:
                    charachater_dict2[j] = [i]
                else:
                    charachater_dict2[j].append(i)
                charachater = j
    if charachater != None:
        for j, k in charachater_dict2.items():
            if charachater == j and i not in [i3 for i3 in k]:
                if j not in charachater_dict2:
                    charachater_dict2[j] = [i]
                else:
                    charachater_dict2[j].append(i)

foldername = os.listdir(path2)

# 转移mod文件并删除原mod文件（进行自动分类）
for j, k in charachater_dict2.items():
    if not os.path.exists(path2+str(j)):
        os.mkdir(path2+j)
    for i in k:
        copyfile(path1+str(i), path2+str(j)+str('\\')+str(i))
        print(f'had removed {path1+str(i)}')
        deletefile(path1+str(i))

