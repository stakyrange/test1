# fixlaunch.py
# 在指定路径运行修复程序
import os
import config

path = config.path3
os.system(f"cd {path} & python ./fix.py")
