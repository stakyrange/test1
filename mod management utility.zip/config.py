# python config.py

# please add '\\' in the end of path, or the code is not expected
# please add '\\' in the end of path, or the code is not expected
# please add '\\' in the end of path, or the code is not expected

# unclassified mod folder
path1 = r'D:\\download\\'  
# classified mod folder or saved mod folder
path2 = r'D:\\game\\mods\\star rail\\' 
# mod loader folder  
path3 = r'D:\\game\\XXMI-Launcher-Portable-v1.3.2\\SRMI\\Mods\\'  
# backup for remove folder
path4 = r'.\\backup\\'  

# please choose the star rail or genshin's charachater_dict and exegesis or not exegesis it\
# to certainly run the autoclassification.py

# charachater name and nickname(star rail)
charachater_dict = {'himeko': ['jizi'], \
                    'welt': ['waerte'], \
                    'silver wolf': ['yinlang', 'hanser'], \
                    'bronya': ['yaya', 'buluoniya'], \
                    'clara': ['kelala'], \
                    'luocha': [], \
                    'jingyuan': [], \
                    'blade': ['ren'], \
                    'fuxuan': [], \
                    'yanqing': [], \
                    'bailu': ['longnv'], \
                    'jingliu': ['taihou'], \
                    'yunli': [], \
                    'fugue': ['wangguiren'], \
                    'ruanmei': [], \
                    'dr.ratio': ['zhenli', 'doctor', 'yisheng'], \
                    'sparkle': ['huahuo', 'huanyu'], \
                    'firefly': ['liuying'], \
                    'march 7th': ['march', 'sanyueqi', 'sanyue'], \
                    'danheng': [], \
                    'arlan': ['alan'], \
                    'asta': ['aisida'], \
                    'herta': ['heita'], \
                    'serval': ['xiluwa'], \
                    'natasha': [], \
                    'pela': ['peila'], \
                    'sampo': ['sangbo'], \
                    'hook': ['huke'], \
                    'lynx': ['lingke'], \
                    'luka': [], \
                    'qingque': [], \
                    'tingyun': [], \
                    'sushang': [], \
                    'yukong': [], \
                    'guinaifen': ['xiaoguizi'], \
                    'xueyi': [], \
                    'hanya': [], \
                    'moze': [], \
                    'gallagher': ['jialahe'], \
                    'misha': ['mika'], \
                    'kafka': ['kafuka'], \
                    'seele': ['xier'], \
                    'gepard': ['jiepade'], \
                    'topaz&numby': ['tuopa', 'zhangzhang', 'topaz', 'numby'], \
                    'danhengimbibitorlunae': ['longdan', 'yinyue'], \
                    'huohuo': [], \
                    'jiaoqiu': [], \
                    'feixiao': [], \
                    'lingsha': [], \
                    'argenti': ['yinzhi', 'chunmei', 'qishi'], \
                    'aventuring': ['shajin'], \
                    'black swan': ['heitiane'], \
                    'acheron': ['huangquan'], \
                    'robin': ['zhigengniao', 'bird'], \
                    'sunday': ['xingqiri', 'fangjiari'], \
                    'jade': ['feicui', 'baoshi', 'jewel'], \
                    'boothill': ['bto', 'botiou'], \
                    'rappa': ['luanpo'], \
                    }

# charachater name and nickname(genshin)
# charachater_dict = {'mavuika': ['maweika', 'huoshen', ], \
#                     'citlali': ['xitelali', 'nainai', 'laodonxi'], \
#                     'chasca': ['qiasika'], \
#                     'ororon': ['ouluolun'], \
#                     'xilonen': ['xiruoning'], \
#                     'kinich': ['jiniqi', 'caolong'], \
#                     'mualani': ['malani'], \
#                     'kachina': ['kaqina'], \
#                     'emilie': ['aimeiliai'], \
#                     'sigewinne': ['xigewen'], \
#                     'clorinde': ['keluolinde'], \
#                     'sethos': ['saisuosi'], \
#                     'arlecchino': ['aleiqinuo', 'puren'], \
#                     'chiori': ['qianzhi'], \
#                     'xianyun': ['liuyun'], \
#                     'gaming': ['jiaming'], \
#                     'chevreuse': ['xiawolei'], \
#                     'navia': ['naweiya'], \
#                     'furina': ['funingna', 'fufu', 'shuishen'], \
#                     'charlotte': ['xialuodi'], \
#                     'wriorthesley': ['laiousili', 'jianyuzhang'], \
#                     'neuvillette': ['naweilaite', 'longwang'], \
#                     'freminet': ['feimini'], \
#                     'lyney': ['linni', 'moshushi'], \
#                     'lynette': ['linnite'], \
#                     'kirara': ['qiniangniang', 'maomao'], \
#                     'baizhu': ['yisheng', 'doctor', ], \
#                     'kaveh': ['kawei'], \
#                     'mika': [], \
#                     'dehya': ['dixiya'], \
#                     'alhaitham': ['aierhaisen'], \
#                     'yaoyao': [], \
#                     'wanderer': ['liulangzhe', 'sanbing'], \
#                     'faruzan': ['falushan', 'qianbei'], \
#                     'layla': ['laiyila'], \
#                     'nahida': ['naxida', 'caoshen'], \
#                     'nilou': ['milu'], \
#                     'cyno': ['sainuo'], \
#                     'candace': ['kandisi'], \
#                     'dori': ['duoli', 'jianshang'], \
#                     'tighnari': ['tinali'], \
#                     'collei': ['kelai'], \
#                     'shikanoin heizou': ['shikanoinheizou', 'luyeyuan', 'pingzang'], \
#                     'kuki shinobu': ['jiuqiren', 'shinobu'], \
#                     'yelan': ['yelan'], \
#                     'kamisato ayato': ['lingren', 'kamisatoayato', 'ayato'], \
#                     'yae miko': ['yaemiko', 'bachongshenzi', 'miko'], \
#                     'shenhe': [], \
#                     'yun jin': ['yunjin'], \
#                     'arataki itto': ['yidou', 'huanglong', 'itto'], \
#                     'gorou': ['wulang'], \
#                     'thoma': ['tuoma'], \
#                     'sangonomiya kokomi': ['kokomi', 'xinhai', 'sangonomiya'], \
#                     'raiden shogun': ['leidian', 'jiangjun', 'leishen', 'raidenshogun', 'raiden', 'shogun'], \
#                     'kujou sara': ['jiutiao', 'shaluo', 'sara', 'kujou'], \
#                     'aloy': ['ailuoyi'], \
#                     'yoimiya': ['xiaogong'], \
#                     'sayu': ['zaoyou'], \
#                     'kamisato ayaka': ['gui', 'linghua', 'ayaka'], \
#                     'kaedehara kazuha': ['wanye', 'kaedeharakazuha', 'kazuha'], \
#                     'eula': ['youla'], \
#                     'yanfei': [], \
#                     'rosaria': ['luoshaliya'], \
#                     'hu tao': ['hutao', 'tangzhu', 'wangshengtang'], \
#                     'xiao': ['xianren'], \
#                     'ganyu': ['yeyang', 'wangxiaomei'], \
#                     'albeto': ['abeduo', 'lianjinshu'], \
#                     'zhongli': ['yanshen', 'dijun'], \
#                     'xinyan': [], \
#                     'tartaglia': ['dadaliya'], \
#                     'diona': ['diana'], \
#                     'klee': ['keli', 'bengbeng'], \
#                     'venti': ['wendi', 'fengshen'], \
#                     'keqing': ['niuza', 'shifu'], \
#                     'mona': ['zhanxing'], \
#                     'qiqi': ['jiangshi'], \
#                     'diluc': ['diluke', 'hongtoufade'], \
#                     'jean': ['qin'], \
#                     'sucrose': ['shatang'], \
#                     'chongyun': [], \
#                     'noelle': ['nuoaier'], \
#                     'bannett': ['bannite'], \
#                     'fischl': ['feixieer'], \
#                     'ningguang': ['fupo'], \
#                     'xingqiu': [], \
#                     'beidou': [], \
#                     'xiangling': ['guoba'], \
#                     'razor': ['leize', 'lang', 'wolf'], \
#                     'barbara': ['babala'], \
#                     'lisa': [], \
#                     'kaeya': ['kaiya'], \
#                     'amber': ['anbo'], \
#                     }