# python removefixedmod.py
# 转移修复好的模组到模组文件夹
import shutil
import os
import csv
import config

# 复制文件（文件夹）
def copyfile(srcpath, dstpath):
    # 如果目标根目录不存在，则创建目标根目录。
    if not os.path.exists(dstpath):
        os.makedirs(dstpath)
    # 遍历源文件夹，得到根目录，子目录和文件名列表
    for root, dirs, files in os.walk(srcpath, topdown=True):
        # 将目录中根目录部分换成目标目录
        path = root.replace(srcpath, dstpath)
        # 在目标目录中,建立与源目录一样的目录体系
        for dir in dirs:
            if not os.path.exists(os.path.join(path, dir)):
                os.makedirs(os.path.join(path, dir))
        #获取文件名依次遍历
        for name in files:
            # 拷贝文件。
            shutil.copy(os.path.join(root, name), os.path.join(path, name))
            # print(f'had remove the fixed mod: {name}')

# 读取模组加载器内的所有mod文件
def recoder():
    file_path = './star rail hadmodname.csv'
    
    # 检查文件是否存在，如果不存在则创建并写入标题
    if not os.path.exists(file_path):
        with open(file_path, 'w', encoding='UTF-8', newline='') as f:
            mod_dict = {'name': 'hadmodname'}
            csv_write = csv.writer(f)
            csv_write.writerow(mod_dict.keys())  # 写入标题行

    # 读取文件内容并更新字典
    with open(file_path, 'r', encoding='UTF-8', newline='') as f:
        reader = csv.DictReader(f)
        mod_dict = {row['name']: row['hadmodname'] for row in reader}

    return mod_dict

# 删除文件夹
def delete_folder(directory):
    shutil.rmtree(directory)
    print(f"已删除: {directory}")

if __name__ == '__main__':
    # 获得模组加载器内所有mod的名字
    mod_dict = recoder()
    # 文件夹路径
    path1 = config.path2
    path2 = config.path3
    # 遍历模组加载器内的所有mod名并转移mod文件进保存所有mod文件的文件夹
    for j, k in mod_dict.items():
        if k != None:
            # print(path2+j, rf'{path}{j}\\{k}')
            # exit()
            delete_folder(rf'{path1}{j}\\{k}')
            copyfile(path2+j, rf'{path1}{j}\\{k}')
            print(f'had remove the fixed mod: {k}')