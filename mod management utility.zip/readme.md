the mod management utility is about auto classify download mod, rar file auto undo,\
delete mod folder's file, mod's transform, fix mod and transform the has fixed mod to mod folder\

before use the utility, please modify the config.py

requirement
python(3.11.7)
os
time
shutil
subprocess
signal
zipfile
rarfile
py7zr
csv

firstly,use autoclassification to clasify download's mod zip file.secondly,please download \
winrar and put the unrar shortcut in the python scripts folder then use rarundo to undo zip file.\
thirdly,manual operation undo failed zip file(it's in the txt file of every charachater's \
folder),then,use deletefiles to delete zip file and txt file.fourth,use rename to certainly\
the mod file in and out are the same, and use writemodname to write every charachater's mod \
in csv file.fifth,use transformod to tramsfor the mod to the mod launcher folder then you can\
see mods in game,if the mod was abnormal,you could modify the fix.py's path and copy it \
to mod launcher folder and run it in the path or run fixlaunch.py in the mod management \
utility folder.lastly,you can use the removefixedmod.py to put the fixed mod in (classified \
mod folder or saved mod folder).

2025-2-1